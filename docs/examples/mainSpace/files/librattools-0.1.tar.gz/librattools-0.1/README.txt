===========
libratTools
===========

libratTools consist of Python modules for the creation of 3D scenes
and running of simulations using *librat*. Primarily used with wavefront
obj files created by the commercial software *OnyxTree*
These were developed for waveform lidar simulations of savanna tree/grass scenes
Many of the methods are Python implementations of ideas/code by Mat Disney (UCL)

Modules can be imported in Python scripts by::

    #!/usr/bin/env python

    # Micellaneous numerical utilites
    from librattools import utilities
    
    # Methods for creating tree/grass scenes
    from librattools import libratscene

    # Methods for querying/modifying librat wavefront object files
    from librattools import libratobject
    
    # Methods for creating height, material and crown maps, HIPS I/O
    # Some methods require the librat "start" program to be in your path
    from librattools import libratmaps
    
    # Methods for querying/modifying OnyxTree wavefront object files
    from librattools import onyxtree
    
    # Methods for simulating airborne/terrestrial survey characteristics
    from librattools import lidarsurvey
    
    # Methods for running batch simulations on the QDERM HPC
    from librattools import pbsbatch
    
    # Methods for configuring camera/light files used by "start"
    from librattools import libratconfig
   
    

Directories
===========
bin::
    command line scripts (see http://librat.wikispaces.com for examples)
    * onyxtree_get_lad.py
        get the leaf angle distribution from an OnyxTree wavefront obj
    * onyxtree_get_par.py
        get a set of commonly measured tree/canopy metrics from an OnyxTree wavefront obj
    * onyxtree_set_lad.py
        set the leaf angle distribution from an OnyxTree wavefront obj
    * onyxtree_to_librat.py
        convert onyxtree to librat wavefront obj files
        options to covert LAD and subset materials used
    * onyxtree_vertical_profile.py
        derive the vertical profile of plant area for each material for an OnyxTree obj file
    * scene_crown_map.py
        create an vertically projected crown extent map of a scene
    * scene_make.py
        make a tree/grass scene for librat simulations
    * scene_vertical_profile.py
        derive the vertical profile of plant area for each material over a scene
    * tree_vertical_profile.py
        derive the vertical profile of plant area for each material for a single librat tree obj

docs::
    html documentation of python modules and python bindings for librat

librattools::
    python modules (see above and docs for description)

src::
    source code for external dependencies
    csh::
        AWK/CSH scripts by Mat Disney (UCL) that are called by Python routines
        required for the onyxtree and libratscene modules
    python::
        source and makefile for librat SWIG python bindings
        required for the libratmaps module
    start::
        alternative version of librat "start" and makefile
        option 17 has been added to create material maps
        required for the libratmaps module
