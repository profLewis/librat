"""
Creating 3D scenes for simulations with librat

Python modules for the creation of 3D scenes
and running of simulations using librat. Primarily used
with wavefront obj files created by the software OnyxTree.
Many of the methods are Python implementations of ideas/code
by Mat Disney (UCL)
"""
