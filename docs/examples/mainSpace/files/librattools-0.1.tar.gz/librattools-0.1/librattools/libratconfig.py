#!/bin/env python
"""
Python classes for interacting with librat and developing 3D tree/grass scenes.
Many of the methods are Python implementations of ideas/code by Mat Disney (UCL)
John Armston (j.armston@uq.edu.au)
"""

import numpy
import os
import sys
import utilities


class libratConfig: 
    """
    Defines the light and camera files
    """
    
    def __init__(self):
        """
        Initialize dictionary
        """      
        self.items = {}

        
    def initAirborneLight(self, lidar=True):
        """
        Initialise an airborne lidar light file
        """
        self.items["camera.name"] = "simple illumination"
        self.items["geometry.perspective"] = True
        self.items["geometry.twist"] = 0.0
        self.items["geometry.lookAt"] = 0.0, 0.0, 0.0
        self.items["geometry.boomLength"] = 0.0
        self.items["geometry.azimuth"] = 0.0
        self.items["geometry.zenith"] = 0.0
        self.items["geometry.fieldOfView"] = 0.0
        self.items["samplingPattern.sd"] = 2.5, 2.5
        if (lidar is True):
            self.items["lidar.pulseStart"] = 500
            self.items["lidar.pulseForm"] = "gaussian"
            self.items["lidar.pulseSD"] = 0.53271920616767998
            self.items["lidar.pulseLength"] = 1000.0
  
            self.items["lidar.pulseSamples"] = 100


    def initAirborneCamera(self, lidar=True, images=False):
        """
        Initialise an airborne lidar camera file
        """   
        self.items = {}
        self.items["camera.name"] = "lidar"
        self.items["geometry.perspective"] = True
        self.items["geometry.lookAt"] = 0, 0, 0
        self.items["geometry.boomLength"] = 1000
        self.items["geometry.azimuth"] = 0.0
        self.items["geometry.zenith"] = 0.0
        self.items["geometry.twist"] = 0.0
        self.items["geometry.fieldOfView"] = 0.115
        self.items["samplingCharacteristics.nPixels"] = 262144
        self.items["samplingCharacteristics.rpp"] = 1

        if (images is True):
            self.items["result.image"] = "results/result.hips"

        self.items["result.integral.mode"] = "distance"
        self.items["result.integral"] = "results/results.dat"

        if (images is True):
            self.items["samplingPattern.OPImage"] = "results/testOPImage.hips"
            self.items["samplingPattern.sampleCountImage"] = "results/testsampleCountImage.hips"
            self.items["samplingPattern.gridMap"] = "results/testgridMap.hips"
            self.items["samplingPattern.modulationMap"] = "results/modmap.hips"

        self.items["samplingPattern.size"] = 512, 512
        self.items["samplingPattern.form"] = "gaussian"
        self.items["samplingPattern.sd"] = 2.5, 2.5
        self.items["samplingPattern.centre"] = 0, 0

        if (lidar is True):
            self.items["lidar.nBins"] = 150
            self.items["lidar.binStart"] = 1966
            self.items["lidar.binStep"] = 0.299792458            


    def getItem(self, item):
        """
        Get camera/light file item
        """
        return self.items[item]

           
    def setItem(self, item, value):
        """
        Set camera/light file item
        """
        self.items[item] = value


    def delItem(self, item):
        """
        Delete camera/light file item
        """
        self.items.pop(item)


    def writeFile(self, fileName='camera_default.dat'):
        """
        Write a camera/light file with current configuration
        """
        obj = open(os.path.join('camera',fileName), 'w')
        obj.write('camera {\n')
        for item in self.items:
            obj.write('    %s = %s;\n' % (item, self.items[item]))
        obj.write('}\n')
        obj.close()

    
    def calcAirborneLidar(self, maxH, delta=5.0, binStep=None):
        """
        Calculate derived airborne camera lidar parameters
        """
        if (binStep is not None): self.items["lidar.binStep"] = binStep
        maxHt = maxH / numpy.cos(numpy.radians(self.items["geometry.zenith"]))
        self.items["lidar.binStart"] = 2.0 * (self.items["geometry.boomLength"] - maxHt - delta)
        self.items["lidar.nBins"] = int(0.5 + (2.0 * self.items["geometry.boomLength"] - self.items["lidar.binStart"] + 2.0 * delta) / self.items["lidar.binStep"])

    
    def calcAirborneGeometry(self, azimuth=None, zenith=None, altitude=1000.0, footprint=0.5):
        """
        Calculate derived airborne lidar geometry parameters
        """
        if (azimuth is not None): self.items["geometry.azimuth"] = azimuth
        if (zenith is not None): self.items["geometry.zenith"] = zenith
        self.items["geometry.boomLen"] = altitude / numpy.radians(self.items["geometry.zenith"])
        idealArea = footprint / (2.0*numpy.sqrt(2.0*numpy.log(2.0))) * self.items["samplingPattern.sd"][0] * self.items["samplingPattern.sd"][1]
        self.items["geometry.fieldOfView"] = numpy.degrees(idealArea / altitude)
        
