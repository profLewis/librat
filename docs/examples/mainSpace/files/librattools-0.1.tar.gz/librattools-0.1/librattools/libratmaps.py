#!/bin/env python
"""
Contains the libratMaps class
"""

import numpy
from osgeo import gdal
from osgeo import gdalconst
from matplotlib import nxutils
import os
import sys
import utilities
import libratobject
import librat # Python bindings


class libratMaps: 
    """
    Methods for creating height, cover and material maps of scenes using start
    """
    
    def __init__(self, scene):
        self.scene = scene
        self.extent = [50,50]
        self.centre = [0,0]
        self.resolution = 0.1
        self.map = None
        self.type = None
        self.boom = 200
        
        
    def getDims(self):
        """
        Calculate scene dimensions
        """
        xDim = int(numpy.floor(self.extent[0]/self.resolution))
        yDim = int(numpy.floor(self.extent[1]/self.resolution))
        return (xDim,yDim)
        
        
    def __cloneCrownByScene(self, x, y, points, crowns, scnClones, scnLevels, level):
        """
        Recursive function to rotate and offset a crown between cloned scenes
        In each iteration the crown map is updated and returned
        """
        xDim, yDim = self.getDims()
        maxLevels = len(scnLevels) - 1
        index = numpy.where(numpy.array(scnClones["g"]) == scnLevels[level])
        for idx in index[0]:
            nextLevel = level
            xr,yr = utilities.rotate2D(x, y, scnClones["rotation"][idx])
            xr1 = xr + scnClones["x"][idx]
            yr1 = yr + scnClones["y"][idx]
            # Don't map to the centre scene as already done in previous level 
            if numpy.logical_or(scnClones["x"][idx] != 0, scnClones["y"][idx] != 0):    
                poly = numpy.array([xr1,yr1]).transpose()
                inside = nxutils.points_inside_poly(points, poly).reshape((xDim,yDim))
                crowns = numpy.where(inside, crowns+numpy.uint(1), crowns)   
            # Map crown to next scene level
            if (level < maxLevels):
                nextLevel += 1
                crowns = self.__cloneCrownByScene(xr1,yr1,points,crowns,scnClones,scnLevels,nextLevel)
        return crowns
        
        
    def crownMap(self, objClones, scnLevels=None, scnClones=None):
        """
        Create a crown map. Crown area treated as the convex hull of the tree material.
        Image values represent the number of intercepted tree crowns.
        """
        # Initialise the output image
        xDim, yDim = self.getDims()
        crowns = numpy.zeros([xDim,yDim], dtype=numpy.uint8)
        xi = numpy.repeat([numpy.arange(xDim)*self.resolution - self.extent[0]/2.0 - self.centre[0] + self.resolution/2.0],yDim,axis=0)
        yi = numpy.repeat([numpy.arange(yDim)*self.resolution - self.extent[1]/2.0 - self.centre[1] + self.resolution/2.0],xDim,axis=0).transpose()
        points = numpy.array([xi.flatten(),yi.flatten()]).transpose()
        nObjects = len(objClones["g"])
        uObjects = set(objClones["g"])
        i = 0
        
        # Get crown of tree
        for tree in uObjects:
            treeObj = libratobject.libratObject(tree)
            chull = treeObj.get_crownExtent()
            index = numpy.where(numpy.array(objClones["g"]) == tree)
            
            # Map each clone of tree
            for idx in index[0]:
                xr,yr = utilities.rotate2D(chull[:,0], chull[:,1], objClones["rotation"][idx])
                xr0 = numpy.append(xr,xr[0])
                yr0 = numpy.append(yr,yr[0])
                poly = numpy.array([xr0+objClones["x"][idx],yr0+objClones["y"][idx]]).transpose()
                inside = nxutils.points_inside_poly(points, poly).reshape((xDim,yDim))
                crowns = numpy.where(inside, crowns+numpy.uint(1), crowns)              
                
                # Clone the clone for each scene
                if scnLevels is not None:
                    x0Temp = xr0+objClones["x"][idx]
                    y0Temp = yr0+objClones["y"][idx]
                    crowns = self.__cloneCrownByScene(x0Temp,y0Temp,points,crowns,scnClones,scnLevels,0)
                
                i += 1            
                sys.stdout.write("Mapping crowns (%i%%)\r" % int(i / float(nObjects) * 100.0))
        
        self.type = "crown"
        self.map = crowns


    def materialMap(self, outFile=None):
        """
        Created a material map. Depends on a version of librats "start" program with option 17 added.
        Image values represent the ID of the highest intercepted scene material within that pixel.
        """
        xDim, yDim = self.getDims()
        if (outFile is None):
            fparts = self.scene.split(".")
            outFile = fparts[0] + "_material.hips"
        cmd = "echo 17 %i %i %i %i %i %i %i 5 %s | start_v20 -RATtolerance 0.0001 %s" % \
        (self.centre[0],self.centre[1],self.boom,self.extent[0],self.extent[1],xDim,yDim,outFile,self.scene)
        os.system(cmd)
        self.type = "material"
        header,self.map = self.readHIPS(outFile)


    def materialIndex(self):
        """
        Get material index for material map
        """      
        ratObj = librat.RATinit()
        status = librat.RATparse(ratObj, 0, None, None)
        librat.RATsetWavefrontFilename(ratObj,self.scene)
        librat.RATreadObject(ratObj)
        matObj,nMat = librat.RATgetMaterials(ratObj)
        name = []
        index = []
        for i in range(nMat):
            result = librat.RATtranslateMaterial(ratObj,i)
            if result is not -1:
                name.append(result[0])
                index.append(result[1])
        ratObj = None
        matObj = None
        return (name,index)
        

    def heightMap(self, outFile=None):
        """
        Created a height (above ground) map. Depends on librats "start" program.
        Image values represent the height of the first intercepted scene material.
        """
        xDim, yDim = self.getDims()
        if (outFile is None):
            fparts = self.scene.split(".")
            outFile = fparts[0] + "_height.hips"
        cmd = "echo 16 %i %i %i %i %i %i %i 1 %s | start_v20 -RATtolerance 0.0001 %s" % \
        (self.centre[0],self.centre[1],self.boom,self.extent[0],self.extent[1],xDim,yDim,outFile,self.scene)
        os.system(cmd)
        self.type = "height"
        header,self.map = self.readHIPS(outFile)


    def readHIPS(self, inFile):
        """
        Read a HIPS file header and image
        """  
        hipsObj = open(inFile, 'rb')
        header = {}
        header['orig_name'] = hipsObj.readline().strip('\r\n')
        header['seq_name'] = hipsObj.readline().strip('\r\n')
        header['num_frame'] = int(hipsObj.readline().strip('\r\n'))
        header['orig_date'] = hipsObj.readline().strip('\r\n')
        header['rows'] = int(hipsObj.readline().strip('\r\n'))
        header['cols'] = int(hipsObj.readline().strip('\r\n'))
        header['bits_per_pixel'] = int(hipsObj.readline().strip('\r\n'))
        header['bit_packing'] = int(hipsObj.readline().strip('\r\n'))
        header['pixel_format'] = int(hipsObj.readline().strip('\r\n'))
        header['seq_history'] = hipsObj.readline().strip('\r\n')
        header['seq_desc'] = hipsObj.readline().strip('\r\n')
        endHeader = hipsObj.readline()
        while (endHeader != '.\n'):
            header['seq_desc'] += endHeader.strip('\r\n')
            endHeader = hipsObj.readline()
        if (header['pixel_format'] == 0):
            image = numpy.fromfile(hipsObj,dtype=numpy.uint8).reshape((header['rows'],header['cols']))
        elif (header['pixel_format'] == 1):
            image = numpy.fromfile(hipsObj,dtype=numpy.uint16).reshape((header['rows'],header['cols']))
        elif (header['pixel_format'] == 2):
            image = numpy.fromfile(hipsObj,dtype=numpy.uint32).reshape((header['rows'],header['cols']))
        elif (header['pixel_format'] == 3):
            image = numpy.fromfile(hipsObj,dtype=numpy.float32).reshape((header['rows'],header['cols']))
        elif (header['pixel_format'] == 4):
            image = numpy.fromfile(hipsObj,dtype=numpy.complex64).reshape((header['rows'],header['cols']))
        elif (header['pixel_format'] == 5):
            image = numpy.fromfile(hipsObj,dtype=numpy.str).reshape((header['rows'],header['cols']))
        else:
            print "HIPS pixel format %i not supported" % header['pixel_format']
            sys.exit()
        hipsObj.close()
        return (header, image)
        
        
    def writeImage(self, outFile=None, format="ENVI"):
        """
        Writes a map to a GDAL supported image file format.
        """
        xDim, yDim = self.getDims()
        if (self.type == "height"):
            dType = gdalconst.GDT_Float32
        else:
            dType = gdalconst.GDT_Byte
        driver = gdal.GetDriverByName(format)
        if (outFile is None):
            fparts = self.scene.split(".")
            outFile = fparts[0] + "_%s.%s" % (self.type,format.lower())
        dst_ds = driver.Create(outFile, xDim, yDim, 1, dType)
        dst_ds.GetRasterBand(1).WriteArray(self.map)
        dst_ds = None
        
