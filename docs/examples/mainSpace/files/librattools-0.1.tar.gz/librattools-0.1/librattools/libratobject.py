#!/bin/env python
"""
Contains the libratObject class
"""

import numpy
import os
import sys
import utilities        


class libratObject:    
    """
    Methods for querying and modifying librat single plant objects
    Currently fairly limited to librat objects created from OnyxTree files
    """

    def __init__(self, objFile=None):     
        self.fileName = objFile
        self.object = {}


    def get_materials(self):
        """
        Returns a list of materials referenced in object
        """
        mat = list(set([line[6:].strip() for line in open(self.fileName, 'r') if line[0:6] == "usemtl"]))
        incFiles = self.get_incFiles()
        for incFile in incFiles:
            tempObj = self.__class__(incFile)
            temp = tempObj.get_materials()
            for tempMat in temp:
                mat.append(tempMat)
        return set(mat)


    def get_sceneName(self):
        """
        Returns the scene name
        """
        groups = [line.split(" ")[1] for line in open(self.fileName, 'r') if line[0:3] == "g "]
        return groups[0]
    
    
    def replace_material(self, old, new):
        """
        Replaces a material name with another
        Used when using different materials for different species
        """
        oldMaterial = "usemtl %s" % old
        newMaterial = "usemtl %s" % new
        newLines = [line.replace(oldMaterial,newMaterial) for line in open(self.fileName, 'r')]
        outFile = open(self.fileName, 'w')
        for line in newLines:
            outFile.write(line)    
        outFile.close()
    
    
    def get_bbox(self):
        """
        Get bounding box of object
        """
        xyz = self.get_vertices()
        if len(xyz) > 0:
            return numpy.array([numpy.amin(xyz, axis=0), numpy.amax(xyz, axis=0)])
        else:
            return None
   
    
    def get_maxH(self):
        """
        Get maximum height of object
        """
        maxH = 0.0
        bbox = self.get_bbox()
        if bbox is not None: maxH = bbox[1,2]
        incFiles = self.get_incFiles()
        for incFile in incFiles:
            tempObj = self.__class__(incFile)
            bbox = tempObj.get_bbox()
            if bbox is not None: maxH = max(maxH, bbox[1,2])
        return maxH
    
    
    def get_nMat(self):
        """
        Returns the total number of materials referenced in object, including sub-objects referenced by #include statements
        """
        mat = self.get_materials()
        return len(set(mat))
    
    
    def get_incFiles(self):
        """
        Returns list of object files referenced by #include statements
        """
        incFiles = [line[8:].strip() for line in open(self.fileName, 'r') if line[0:8] == "#include"]
        return incFiles
    
    
    def get_vertices(self):
        """
        Returns x,y,z of all vertices as an m by n array
        """
        xyz = [line[2:].strip("\r\n").split(" ") for line in open(self.fileName, 'r') if line[0] == "v"]
        return numpy.array(xyz, dtype="Float32")


    def read_obj(self):
        """
        Read librat object for an individual plant
        Only parses facets within bounding boxes, so not very general yet...
        """
        self.object["v"] = []
        self.object["local"] = []
        self.object["n"] = []
        self.object["f"] = []
        self.object["fi"] = []
        self.object["usemtl"] = []
        self.object["bbox"] = []
        self.object["nfacets"] = []
        nVertices = 0

        obj = open(self.fileName, 'r')
        bboxStart = False
        for line in obj:
            lparts = line.strip('\r\n').split(' ')
            if (len(lparts) > 1):
                if line.startswith("g box"):
                    self.object["bbox"].append(lparts[2])
                    self.object["nfacets"].append(0)
                    bboxStart = True
                else:
                    if bboxStart:
                        if (lparts[0] == "usemtl"):
                            self.object["usemtl"].append(lparts[1])
                            nFacets = 0
                        elif (lparts[0] == "v"):
                            self.object["v"].append([float(i) for i in lparts[1:]])
                            nVertices += 1
                        elif (lparts[0] == "!local"):
                            self.object["local"].append([float(i) for i in lparts[1:]])                   
                        elif (lparts[0] == "!n"):
                            self.object["n"].append([float(i) for i in lparts[1:]])                   
                        elif (lparts[0] == "f"):
                            self.object["f"].append([int(i) for i in lparts[1:]])
                            self.object["nfacets"][-1] += 1
                            nFacets += 1
                            for i in lparts[1:]:
                                self.object["fi"].append(nVertices + int(i))
                            if (nFacets > 1):
                                self.object["usemtl"].append(self.object["usemtl"][-1])
        
        obj.close()


    def get_facetVertices(self,material="All"):
        """
        Returns n by m arrays for x, y and z vertices of facets.
        n is the number of facets and m is the number vertices per facet (3)
        """
        if material == "All":
            x = numpy.array(self.object["v"])[self.object["fi"],0]
            y = numpy.array(self.object["v"])[self.object["fi"],1]
            z = numpy.array(self.object["v"])[self.object["fi"],2]
        else:
            index = numpy.where(self.object["usemtl"] == material)
            x = numpy.array(self.object["v"][index[0]])[self.object["fi"][index[0]],0]
            y = numpy.array(self.object["v"][index[0]])[self.object["fi"][index[0]],1]
            z = numpy.array(self.object["v"][index[0]])[self.object["fi"][index[0]],2]
        fx = x.reshape([-1,3])
        fy = y.reshape([-1,3])
        fz = z.reshape([-1,3])
        return (fx,fy,fz)       


    def get_facetAngle(self,fx,fy,fz):
        """
        Get the zenith angle of each facet normal
        """
        nx,ny,nz = utilities.calcFaceNormal(fx,fy,fz)       
        a = numpy.array([nx,ny,nz]).transpose()
        b = numpy.array([0,1,0])
        angles = numpy.arccos(dot(a,b)) * 180.0 / numpy.pi
        return angles
            
            
    def get_facetAreaBin(self,fxyz,binsize=0.5,maxVal=50.0,material=""):
        """
        Calculates total area in height bins for a size and material
        """
        bins = numpy.arange(start=0.0, stop=maxVal, step=binsize)
        area = numpy.zeros(len(bins))
        normal = numpy.array([0.0,0.0,1.0])
        
        for n,bin in enumerate(bins):
        
            # Get all facets overlapping bin
            index = numpy.where(numpy.logical_and(numpy.amax(fxyz[2], axis=1) >= bins[n], numpy.amin(fxyz[2], axis=1) <= (bin+binsize)))

            # Intersect each facet with bin
            for i in index[0]:

                # Get vertices of facets at bin edges
                fxBin = fxyz[0][i]
                fyBin = fxyz[1][i]
                fzBin = fxyz[2][i]
                for j in [[0,1],[0,2],[1,2]]:

                    # Get individual facet
                    p1 = numpy.array([fxBin[j[0]],fyBin[j[0]],fzBin[j[0]]])
                    p2 = numpy.array([fxBin[j[1]],fyBin[j[1]],fzBin[j[1]]])

                    # Intersect with lower bin edge
                    plint = utilities.planeInt(p1, p2, normal, numpy.array([0.0,0.0,bin]))
                    if numpy.logical_and(min(p1[2],p2[2]) < bin, max(p1[2],p2[2]) > bin):
                        fxBin = numpy.hstack((fxBin,plint[0]))
                        fyBin = numpy.hstack((fyBin,plint[1]))
                        fzBin = numpy.hstack((fzBin,plint[2]))

                    # Intersect with upper bin edge
                    plint = utilities.planeInt(p1, p2, normal, numpy.array([0.0,0.0,bin+binsize]))
                    if numpy.logical_and(min(p1[2],p2[2]) < (bin+binsize), max(p1[2],p2[2]) > (bin+binsize)):
                        fxBin = numpy.hstack((fxBin,plint[0]))
                        fyBin = numpy.hstack((fyBin,plint[1]))
                        fzBin = numpy.hstack((fzBin,plint[2]))                

                # Remove vertices outside bin and get area of resulting 3D polygon
                idx = numpy.where(numpy.logical_and(fzBin >= bin, fzBin <= (bin+binsize)))
                s = utilities.counterClockwiseSort(numpy.array([fxBin[idx],fyBin[idx],fzBin[idx]]).transpose())
                area[n] += utilities.calc3DPolyArea(fx=fxBin[idx][s], fy=fyBin[idx][s], fz=fzBin[idx][s])
                
            # Show progress
            sys.stdout.write("   extracting %s vertical profile (%i%%)\r" % (material, int(n / float(len(bins)) * 100.0)))

        return (bins, area)
    
    
    def get_stemSection(self, height=1.3, material="Trunk"):    
        """
        Extracts a cross section of the stem at a nominated height in m.
        Works out points where facet edges intersect a plane at the set height.
        If the stem material is not "Trunk", it must be provided as an argument.
        Output is an n (number of vertices) by 2 (x,y) array of vertex coordinates
        """
        fx,fy,fz = self.get_facetVertices()
        materials = numpy.array(self.object["usemtl"])
        index = numpy.where(reduce(numpy.logical_and, [numpy.amin(fz, axis=1) <= height, numpy.amax(fz, axis=1) >= height, materials == material]))
        for i in index[0]:

            for j in [[0,1],[0,2],[1,2]]:
                p1 = numpy.array([fx[i][j[0]],fy[i][j[0]],fz[i][j[0]]])
                p2 = numpy.array([fx[i][j[1]],fy[i][j[1]],fz[i][j[1]]])
                plint = utilities.planeInt(p1, p2, numpy.array([0.0,0.0,1.0]), numpy.array([0.0,0.0,height]))

                if numpy.logical_and(min(p1[2],p2[2]) <= height, max(p1[2],p2[2]) >= height):
                    try:
                        tVertices
                    except NameError:
                        tVertices = plint
                    else:
                        tVertices = numpy.vstack((tVertices,plint))

        return tVertices


    def get_crownExtent(self):
        """
        Extracts the convex hull points the crown
        """
        xyz = self.get_vertices()
        chull = utilities.convex_hull(xyz[:,0],xyz[:,1])
        return chull


    def gen_grassVertices(self, meanHeight, varHeight, nStems, crownRadius):
        """
        A plant is modelled as nStems stems with base length of meanHeight m
        varying randomly by up to +/- varHeight m in height. The stems are distributed in a
        Fibonacci spiral phyllotaxy (spatial arrangement) around the central point, with the
        angle from the vertical determined by the degree of rotation through the spiral
        Disney et al. (2010).
        """
        goldenAngle = numpy.pi * (3.0 - numpy.sqrt(5.0))
        angle = numpy.arange(nStems) * goldenAngle
        spiral_rad = numpy.random.uniform(size=nStems) * crownRadius
        x = numpy.cos(angle) * spiral_rad
        y = numpy.sin(angle) * spiral_rad
        z = numpy.random.uniform(low=meanHeight-varHeight, high=meanHeight+varHeight, size=nStems)
        return (x,y,z)


    def get_cylArea(self, x, y, z, stemRadius):
        """
        Determine the area of a group of cylinders
        """
        length = numpy.sqrt(x**2 + y**2 + z**2)
        area = 2.0 * numpy.pi * stemRadius**2 + 2.0 * numpy.pi * stemRadius * length
        return numpy.sum(area)


    def write_grassVertices(self, x, y, z, name, n, stemRadius, material):
        """
        Writes grass vertices to a librat object file
        Each stem is a cylinder with an origin of 0.0 and a radius of stemRadius
        """
        outFile = '.'.join([name, str(n), "obj"])
        outObj = open(outFile, 'w')
        outObj.write("!{\n")
        outObj.write("#define\n")
        outObj.write("g %s %i\n" % (name, n))
        outObj.write("!{\n")
        outObj.write("usemtl %s\n" % material)
        for i in range(len(x)):
            outObj.write("v 0 0 0\n")
            outObj.write("v %f %f %f\n" % (x[i],y[i],z[i]))
            outObj.write("cyl -1 -2 %f\n" % stemRadius)
        outObj.write("!}\n")
        outObj.write("!}\n")
        outObj.close()
        return outFile

