#!/bin/env python
"""
Contains the libratScene class
"""

import numpy
from scipy import spatial
import os
import sys
import utilities        


class libratScene:    
    """
    Methods for creating and querying scenes of librat scene object files
    """

    def __init__(self):
        self.scene = {}
        self.nObjects = 0
        self.extent = [50,50]
        self.objectFile = None
        

    def sortBoundingBoxes(self, nBoxesX=20, nBoxesY=20):
        """
        Sorts the object positions into bounding boxes
        Returns a tuple of arrays with the x,y,n box number each object falls within
        """      
        xspacing = self.extent[0] / nBoxesX
        yspacing = self.extent[1] / nBoxesY
        
        xbins = (numpy.arange(nBoxesX+1) * xspacing) - (self.extent[0] / 2.0)
        ybins = (numpy.arange(nBoxesY+1) * yspacing) - (self.extent[1] / 2.0)
        
        dx = numpy.digitize(self.scene["x"], xbins)
        dy = numpy.digitize(self.scene["y"], ybins)
        
        dn = (dx-1) + (nBoxesX * (dy-1))
        return (dx,dy,dn)


    def readObjList(self, objList, positions=False):
        """
        Read a comma delimited file (e.g., plants.dat) of objects to include within the scene
        When positions are defined (e.g., by field measurement), the CSV fields are:
            object,species,status,x,y,z,rotation,group,plantNumber (set rotation to zero if done later)
        Status can be "live" or "dead"
        When a random or Neyman Type A distribution will be used to define object positions, the CSV fields are:
            object,species,status,nClones,group,plantNumber
        A dictionary with the keys object,species,status,x,y,z,rotation,group is returned.
        """
        sceneObj = open(objList, 'r')
        sceneDict = {}
        sceneDict["object"] = []
        sceneDict["species"] = []
        sceneDict["status"] = []
        sceneDict["x"] = []
        sceneDict["y"] = []
        sceneDict["z"] = []
        sceneDict["rotation"] = []
        sceneDict["g"] = []
        sceneDict["n"] = []

        for line in sceneObj:
            lparts = line.strip('\r\n').split(',')

            if positions:
                sceneDict["object"].append(lparts[0])
                sceneDict["species"].append(lparts[1])
                sceneDict["status"].append(lparts[2])
                sceneDict["x"].append(float(lparts[3]))
                sceneDict["y"].append(float(lparts[4]))
                sceneDict["z"].append(float(lparts[5]))
                sceneDict["rotation"].append(float(lparts[6]))
                sceneDict["g"].append(lparts[7])
                sceneDict["n"].append(int(lparts[8]))    
            else:
                nClones = int(lparts[3])
                for clone in range(nClones):
                    sceneDict["object"].append(lparts[0])
                    sceneDict["species"].append(lparts[1])
                    sceneDict["status"].append(lparts[2])
                    sceneDict["x"].append(0.0)
                    sceneDict["y"].append(0.0)
                    sceneDict["z"].append(0.0)
                    sceneDict["rotation"].append(0.0)
                    sceneDict["g"].append(lparts[4])
                    sceneDict["n"].append(int(lparts[5]))
        
        sceneObj.close()
        self.nObjects = len(sceneDict["object"])
        self.scene = sceneDict


    def writeObjList(self, outFile, positions=True):
        """
        Write a comma delimited file (e.g., plants.dat) of objects included within a scene and their positions
        """
        sceneObj = open(outFile, 'w')
        for i in range(self.nObjects):
            if positions:
                line = "%s,%s,%s,%f,%f,%f,%f,%s,%i\n" % (self.scene["object"][i],self.scene["species"][i],self.scene["status"][i], \
                self.scene["x"][i],self.scene["y"][i],self.scene["z"][i],self.scene["rotation"][i],self.scene["g"][i],self.scene["n"][i])
            else:
                line = "%s,%s,%s,%i,%s,%i\n" % (self.scene["object"][i],self.scene["species"][i],self.scene["status"][i], 1, \
                self.scene["g"][i],self.scene["n"][i])                
            sceneObj.write(line)
        sceneObj.close()


    def rotateObjects(self, low=0.0, high=360.0):
        """
        Randomly rotate objects between low and high thresholds in degrees.
        If not called, object rotation is set to zero in readObjList by default.
        """
        rTemp = numpy.random.uniform(low=low, high=high, size=self.nObjects)
        self.scene["rotation"] = list(rTemp)


    def readScene(self):
        """
        Read the positions and rotation of all clones
        Assumes Rx|Ry|Rz are not used
        Returns two dictionaries and two lists:
            plant object clones
            scene clones
            scene levels (list)
            include files (list)
        """
        scnLevels = []
        incFiles = []
        scnClones = {"x":[],"y":[],"z":[],"rotation":[],"g":[],"n":[]}
        objClones = {"x":[],"y":[],"z":[],"rotation":[],"g":[],"n":[]}
        for line in open(self.objectFile, 'r'):
            lparts = line.strip('\r\n').split()
            if line.startswith("#include"):
                incFiles.append(lparts[1])
            elif line.startswith("g "):
                if lparts[1] != "box":
                    scnLevels.append(lparts[1])
            elif lparts[0] == "clone":
                if scnLevels.count(lparts[5]) > 0:
                    scnClones["g"].append(lparts[5])
                    scnClones["x"].append(float(lparts[1]))
                    scnClones["y"].append(float(lparts[2]))
                    scnClones["z"].append(float(lparts[3]))
                    scnClones["rotation"].append(float(lparts[4]))
                    scnClones["n"].append(int(lparts[6]))
                else:
                    objClones["g"].append(lparts[5])
                    objClones["x"].append(float(lparts[1]))
                    objClones["y"].append(float(lparts[2]))
                    objClones["z"].append(float(lparts[3]))
                    objClones["rotation"].append(float(lparts[4]))
                    objClones["n"].append(int(lparts[6]))
        return (objClones,scnClones,scnLevels,incFiles)

        
    def writeClones(self, outFile, nBoxes=20):
        """
        Writes clones to a wavefront format file
        Clones are sorted into a simple 2D grid
        """
        if not os.path.isfile(outFile):            
            sceneObj = open(outFile, 'w')
            sceneObj.write("!{\n")
            sceneObj.write("#define\n")
            sceneObj.write("g %s 0\n" % outFile)     
            dx,dy,dn = self.sortBoundingBoxes(nBoxesX=nBoxes, nBoxesY=nBoxes)
            udn = numpy.unique(dn)
            for box in udn:
                sceneObj.write("!{\n")
                index = numpy.where(dn == box)                
                for i in index[0]:
                    sceneObj.write("clone %f %f %f %f %s %i\n" % \
                    (self.scene["x"][i],self.scene["y"][i],self.scene["z"][i],self.scene["rotation"][i],self.scene["g"][i],self.scene["n"][i]))
                sceneObj.write("!}\n")
            sceneObj.write("!}\n")
            sceneObj.close()        
        else:
            print "ERROR: %s already exists" % outFile
            sys.exit()
            

    def writeBoundedClones(self, outFile, nLevels=3, maxHeight=2.0):
        """
        Writes clones to a wavefront format file
        Clones are filtered into bounding boxes using AWK/CSH code by Mat Disney
        Dependencies (need to be in your path):
           boundObj.awk
           clearEmpties.awk
        """
        if not os.path.isfile(outFile):
            outObj = open(outFile, 'w')
            for i in range(self.nObjects):
                outObj.write("clone %f %f %f %f %s %i\n" % \
                (self.scene["x"][i],self.scene["y"][i],self.scene["z"][i],self.scene["rotation"][i],self.scene["g"][i],self.scene["n"][i]))
            outObj.close()
            extent = self.extent[0] / 2.0
            os.system("$LIBRATTOOLS/src/csh/filtClones -i %s -o %s -extent %f -m %f -h %i" % (outFile, outFile, extent, maxHeight, nLevels))             
        else:
            print "ERROR: %s already exists" % outFile
            sys.exit()
            

    def writeScene(self, outFile, matlib, groundSceneObj, treeScene=None, grassScene=None, upSize=True, cloneScene=1, rotateCloneScene=True):
        """
        Writes the ground, tree and grass scenes to a wavefront format file for input to librat
        Set upSize to True to clone scene by the levels set.
        """
        sceneObj = open(outFile, 'w')
        sceneObj.write("mtllib %s\n" % matlib)
        sceneObj.write("!{\n")
        sceneObj.write("g lidarScene0 0\n")
        sceneObj.write("!{\n")
        sceneObj.write("#include %s\n" % groundSceneObj)
                
        # Write included files
        if (grassScene is not None):
            grassInc = list(numpy.unique(grassScene.scene["object"]))
            for grass in grassInc:
                sceneObj.write("#include %s\n" % grass)
            sceneObj.write("#include %s\n" % grassScene.objectFile)
        if (treeScene is not None):
            treeInc = list(numpy.unique(treeScene.scene["object"]))
            for tree in treeInc:
                sceneObj.write("#include %s\n" % tree)
            sceneObj.write("#include %s\n" % treeScene.objectFile)            
              
        # Write clones  
        if (grassScene is not None):    
            sceneObj.write("!{\n")
            sceneObj.write("clone 0 0 0 0 %s 0\n" % grassScene.objectFile)
            sceneObj.write("!}\n")
        if (treeScene is not None):
            sceneObj.write("!{\n")
            sceneObj.write("clone 0 0 0 0 %s 0\n" % treeScene.objectFile)
            sceneObj.write("!}\n")

        sceneObj.write("!}\n")
        sceneObj.write("!}\n")

        if cloneScene:
            sRotations = [0,90,180,270]
            for level in range(cloneScene):
                sceneObj.write("!{\n")
                if (level != (cloneScene-1)): sceneObj.write("#define\n")
                sceneObj.write("g lidarScene%i 0\n" % (level+1))
                offset = 2**(level+1)-1
                for x in range(-1,2,1):
                    for y in range(-1,2,1):
                        if rotateCloneScene:
                            if numpy.logical_and(x == 0, y == 0):
                                sRotation = 0.0
                            else:
                                sRotation = sRotations[numpy.random.random_integers(low=0,high=3,size=1)]
                        else:
                            sRotation = 0.0
                        sceneObj.write("clone %f %f 0 %f lidarScene%i 0\n" % (self.extent[0]*x*offset,self.extent[1]*y*offset,sRotation,level))
                sceneObj.write("!}\n")

        sceneObj.close()
    
    
    def getPlantDensity(self, cover, radius=0.25, Pgap=0.0, unitArea=1.0, leafArea=None, G=0.5, omega=1.0):
        """
        This function is just in place for testing... don't use it
        Calculate the number of plants per unit area required to get the specified cover.
        Uses a Boolean model, so crowns are assumed to follow a Poisson distribution.
        Since often unknown for grass, crown cover is substituted with -cover/(Pgap - 1)
        Alternatively, we measured apparent cover but know the LAI of the grass exactly.
            cover = the fractional cover of the scene
            Pgap = the canopy (not scene) gap fraction
            radius = the mean crown radii
            unitArea = the unit area (default 1 m2)
        """
        if leafArea is not None:
            L = numpy.log(-1.0/(cover - 1.0))/(G*omega)
            pDensity = L / (leafArea / unitArea)
        else:
            #pDensity = numpy.log(Pgap / (cover + Pgap - 1.0) - 1.0 / (cover + Pgap - 1.0)) / (numpy.pi*radius**2)
            pDensity = numpy.log(-1.0/(cover - 1.0))/(numpy.pi*radius**2) * unitArea
        return int(round(pDensity))
      
        
    def positionsNeymanA(self, m2=1, quadDims=[4,4]):
        """
        Calculates x and y positions for the Neyman Type A distribution
        See the defineNeymanA function for details on input parameters
        """
        nQuad = quadDims[0] * quadDims[1]
        xQuadSize = self.extent[0] / float(quadDims[0])
        yQuadSize = self.extent[1] / float(quadDims[1])

        # Create and sample from Neyman distribution
        m = self.nObjects / nQuad
        # m1 = m / m2
        # v = m1*m2*(1+m2)
        trees, prob = utilities.defineNeymanA(nPoints=155, m2=m2, m=m)
        cumNeyman = numpy.cumsum(prob)

        # Determine positions
        xPos = numpy.array([])
        yPos = numpy.array([])
        for yquad in numpy.arange(quadDims[1]):
            for xquad in numpy.arange(quadDims[0]):
                idx = numpy.where(cumNeyman >= numpy.random.uniform())
                if (idx[0].size > 1):
                    nTrees = trees[idx][1]
                    xCen = (xQuadSize * xquad) + xQuadSize/2.0 - self.extent[0]/2.0
                    yCen = (yQuadSize * yquad) + yQuadSize/2.0 - self.extent[1]/2.0
                    xTemp = numpy.random.uniform(low=xCen-(xQuadSize/2.0), high=xCen+(xQuadSize/2.0), size=nTrees)
                    yTemp = numpy.random.uniform(low=yCen-(yQuadSize/2.0), high=yCen+(yQuadSize/2.0), size=nTrees)
                    xPos = numpy.append(xPos, xTemp)
                    yPos = numpy.append(yPos, yTemp)

        # Randomly remove/add trees to ensure total number of positions is equal to number of objects
        # And hope it doesn't change the statistical properties of the tree distribution... dodgy
        nDiff = self.nObjects - xPos.size
        if (nDiff < 0):
            idx = numpy.ones(xPos.size)            
            idx[nDiff:] = 0
            numpy.random.shuffle(idx)
            xPos = xPos[numpy.where(idx)]
            yPos = yPos[numpy.where(idx)]
        elif (nDiff > 0):
            xTemp = numpy.random.uniform(low=-self.extent[0]/2.0, high=self.extent[0]/2.0, size=nDiff)
            yTemp = numpy.random.uniform(low=-self.extent[1]/2.0, high=self.extent[1]/2.0, size=nDiff)
            xPos = numpy.append(xPos, xTemp)
            yPos = numpy.append(yPos, yTemp)
        
        self.scene["x"] = list(xPos)
        self.scene["y"] = list(yPos)


    def positionsRandom(self):
        """
        Calculates x and y positions for a random distribution of trees
        """    
        xPos = numpy.random.uniform(low=-(self.extent[0]/2.0), high=(self.extent[0]/2.0), size=self.nObjects)
        yPos = numpy.random.uniform(low=-(self.extent[1]/2.0), high=(self.extent[1]/2.0), size=self.nObjects)
        self.scene["x"] = list(xPos)
        self.scene["y"] = list(yPos)


    def positionsUniform(self,xSpacing,ySpacing,xJitter=0.5,yJitter=0.5):
        """
        Calculates x and y positions for a uniform distribution of trees/grasses
        If [xy]Jitter is specified, the position of the each plant is randomly positioned within 
        the specified fraction of [xy]Spacing from the original position
        """       
        xPos = numpy.arange(-self.extent[0]/2.0, self.extent[0]/2.0, xSpacing)
        if xJitter > 0:
            xPos += numpy.random.uniform(low=-xSpacing*xJitter,high=xSpacing*xJitter,size=xPos.size)
        self.scene["x"] = list(xPos)
        
        yPos = numpy.arange(-self.extent[1]/2.0, self.extent[1]/2.0, ySpacing)
        if yJitter > 0:
            yPos += numpy.random.uniform(low=-ySpacing*yJitter,high=ySpacing*yJitter,size=yPos.size)  
        self.scene["y"] = list(yPos)


    def checkTreeSpacing(self, minSpacing=2, maxIter=1000, maxChange=None):
        """
        Recalculates random x/y coordinates for points that are within a set distance to their nearest neighbor.
        If the maximum number of iterations is reached, the points within minSpacing are retained.
        Returns the remaining number of points within minSpacing
        """
        inPos = numpy.array([self.scene["x"],self.scene["y"]]).transpose()
        outPos = inPos
        #ix,jx = triu_indices(self.nObjects,1)
        ix,jx = numpy.where(numpy.subtract.outer(numpy.arange(self.nObjects), numpy.arange(self.nObjects)) < 0)
        
        for i in numpy.arange(maxIter):

            dm = spatial.distance.pdist(outPos, 'euclidean')
            index = numpy.where(dm < minSpacing)
            n = index[0].size

            if (n > 0):
                if maxChange is None:
                    try:
                        xTemp = numpy.random.uniform(low=-(self.extent[0]/2.0), high=(self.extent[0]/2.0), size=n)
                        yTemp = numpy.random.uniform(low=-(self.extent[1]/2.0), high=(self.extent[1]/2.0), size=n)
                        outPos[ix[index]] = numpy.array([xTemp,yTemp]).transpose()
                    except:
                        print "Indexing error in tree spacing check"
                else:
                    try:
                        xTemp = numpy.random.uniform(low=-maxChange, high=maxChange, size=n) + inPos[ix[index]][:,0]
                        yTemp = numpy.random.uniform(low=-maxChange, high=maxChange, size=n) + inPos[ix[index]][:,1]
                        xInside = numpy.logical_and(xTemp > -self.extent[0]/2.0, xTemp < self.extent[0]/2.0)
                        yInside = numpy.logical_and(yTemp > -self.extent[1]/2.0, yTemp < self.extent[1]/2.0)                        
                        xTemp = numpy.where(numpy.logical_and(xInside,yInside), xTemp, inPos[ix[index]][:,0])
                        yTemp = numpy.where(numpy.logical_and(xInside,yInside), yTemp, inPos[ix[index]][:,1])
                        outPos[ix[index]] = numpy.array([xTemp,yTemp]).transpose()
                    except:
                        print "Indexing error in tree spacing check"
            else:
                break

        self.scene["x"] = [item[0] for item in outPos]
        self.scene["y"] = [item[1] for item in outPos]
        
        return n
        
