#!/bin/env python
"""
Contains the OnyxTree class
"""

import numpy
from scipy import spatial
import os
import sys
import utilities


class OnyxTree:
    """
    Methods for querying and modifying *.obj wavefront files produced by the software OnyxTree
    Filtering/bounding of OnyxTree files for input to librat uses UCL AWK scripts by Mat Disney.
    OnyxTree uses a "left-handed" coordinate system so need to switch y and z vertices
    """
    
    def __init__(self, objFile):     
        self.fileName = objFile
        self.object = {}


    def readObj(self):
        """
        Read OnyxTree wavefront object
        """
        self.object["v"] = []
        self.object["vn"] = []
        self.object["vt"] = []
        self.object["f"] = []
        self.object["vid"] = []
        self.object["fid"] = []
        self.object["subObject"] = []
        self.object["g"] = []
        self.object["s"] = []
        self.object["include"] = []

        obj = open(self.fileName, 'r')
        for line in obj:
            lparts = line.strip('\r\n').split(' ')

            if (len(lparts) > 1):
                if (lparts[1] == "Sub-Object"):
                    self.object["subObject"].append(lparts[2])
                    self.object["include"].append(True)
                elif (lparts[0] == "v"):
                    self.object["v"].append([float(i) for i in lparts[1:]])
                    self.object["vid"].append(self.object["subObject"][-1])
                elif (lparts[0] == "vn"):
                    self.object["vn"].append([float(i) for i in lparts[1:]])                   
                elif (lparts[0] == "vt"):
                    self.object["vt"].append([float(i) for i in lparts[1:]])
                elif (lparts[0] == "f"):
                    self.object["f"].append([int(index.split('/')[0]) for index in lparts[1:]])
                    self.object["fid"].append(self.object["subObject"][-1])
                elif (lparts[0] == "s"):
                    self.object["s"].append(int(lparts[1]))
                elif (lparts[0] == "g"):
                    self.object["g"].append(lparts[1])                                       

        obj.close()

    
    def getItem(self, item):
        """
        Get OnyxTree object item
        """
        return self.object[item]            

    
    def writeOnyxObj(self, outFileName):
        """
        Write the OnyxTree wavefront object
        outFileName must be provided
        Original copyright statement is retained.
        """
        obj = open(outFileName, 'w')
        obj.write("# Onyx Obj Export Version 1.4 Aug 17th, 2000\n")
        obj.write("# Copyright 2000 by Onyx Computing, Inc. All rights reserved.\n")
        obj.write("\n")
        obj.write("# Warning: This computer model is protected by copyright law and\n")
        obj.write("# international treaties. Unauthorized reproduction or distribution of\n")
        obj.write("# this model, or any derivative or portion of it, may result in severe\n")
        obj.write("# civil or criminal penalties, and will be prosecuted to the maximum\n")
        obj.write("# extent possible under the law.\n")
        obj.write("\n")
        obj.write("mtllib %s.mtl\n" % self.fileName.split('.')[0])
        obj.write("\n")
        obj.write("g OnyxTREE\n")
        obj.write("\n")
        offset = 0

        for i,subObject in enumerate(self.object["subObject"]):
            
            if self.object["include"][i] is True:
            
                obj.write("# Sub-Object %s\n" % subObject)
                obj.write("#\n")

                nv = self.object["vid"].count(subObject)
                iv = self.object["vid"].index(subObject)
                for vertex in self.object["v"][iv:iv+nv]:
                    obj.write("v %f %f %f\n" % (vertex[0],vertex[1],vertex[2]))
                obj.write("# %i vertices\n" % nv)
                obj.write("\n")

                for vertex in self.object["vt"][iv:iv+nv]:
                    obj.write("vt %f %f %f\n" % (vertex[0],vertex[1],vertex[2]))
                obj.write("# %i texture vertices\n" % nv)            
                obj.write("\n")

                for vertex in self.object["vn"][iv:iv+nv]:
                    obj.write("vn %f %f %f\n" % (vertex[0],vertex[1],vertex[2]))
                obj.write("# %i normals\n" % nv)
                obj.write("\n")
                obj.write("usemtl %s\n" % subObject)
                obj.write("s %i\n" % self.object["s"][i])
                obj.write("g %s\n" % self.object["g"][i+1])

                nv = self.object["fid"].count(subObject)
                iv = self.object["fid"].index(subObject)
                for face in self.object["f"][iv:iv+nv]:
                    obj.write("f %i/%i/%i %i/%i/%i %i/%i/%i\n" % \
                    (face[0]-offset,face[0]-offset,face[0]-offset,face[1]-offset,face[1]-offset,face[1]-offset,face[2]-offset,face[2]-offset,face[2]-offset))            
                if (subObject == "Leaf01"):
                    obj.write("# %i faces\n" % nv)
                obj.write("\n")
                
            else:
            
                offset += self.object["vid"].count(subObject)
                

        obj.write("# EOF\n")                  
        obj.close()
        self.FileName = outFileName

        
    def filterObj(self, outFile):
        """
        Filters OnyxTree wavefront objects files and sorts into bounding boxes for librat.
        This is simply a wrapper for the filtOnyx AWK/CSH script by Mat Disney (renamed filtOnyxTree and with minor modifications)
        Dependencies (need to be in your path):
           filtOnyxTree
           filtOnyxTree.awk
           boundObj.awk
           clearEmpties.awk
           wavefront_bbox
        """
        if not os.path.isfile(outFile):
            os.system("$LIBRATTOOLS/src/csh/filtOnyxTree -i %s -o %s -bbox -matmap" % (self.fileName, outFile))
        else:
            print "      %s already exists" % outFile

    
    def getLeafAngles(self):
        """
        Calculates angle of all individual leaves from vector normals.
        Assumes each leaf has two triangles and constant vertex normals (i.e., flat).
        The dot product of two unit vectors is equal to the cosine of the angle between them.
        The arccos of the dot product of the vector normal and the "up" vector normal gives
        the angle of the leaf facet (from the horizontal)      
        """
        index = numpy.where(numpy.logical_or(numpy.array(self.object["vid"]) == "Leaf1",numpy.array(self.object["vid"]) == "Leaf01"))
        if index[0].size > 0:
            a = numpy.array(self.object["vn"])[index][numpy.arange(0,index[0].size-1,4)]
            b = numpy.array([0,1,0])
            angles = numpy.arccos(numpy.dot(a,b)) * 180.0 / numpy.pi
            return angles
        else:
            return None


    def setLeafAngles(self,distribution="random",mla=None):
        """
        Adjusts zenith and vertex normal of all leaf plates to correspond to a known leaf angle distribution.
        Distributions:
            Uniform random distribution (spherical)
            Uniform (constant) - mainly for testing
        """
        
        # Origin is leaf base, assuming following order of vertices:
        # f 1/1/1 2/2/2 3/3/3
        # f 1/1/1 3/3/3 4/4/4
        leafVertices = self.getLeafVertices()
        if leafVertices is not None:
            
            # Separate components of vertices
            x,y,z,nx,ny,nz = leafVertices

            # Translate X so rotation axis runs through origin
            xv = x[:,3] - x[:,0]
            x0 = numpy.repeat([x[:,0] + xv/2.0],4,axis=0).transpose()
            xt = x - x0

            # Translate Y so rotation axis runs through origin
            yv = y[:,3] - y[:,0]
            y0 = numpy.repeat([y[:,0] + yv/2.0],4,axis=0).transpose()
            yt = y - y0
            
            # Translate Z so rotation axis runs through origin
            zv = z[:,3] - z[:,0]
            z0 = numpy.repeat([z[:,0] + zv/2.0],4,axis=0).transpose()
            zt = z - z0

            # Reformat axis vectors about which to perform rotation
            # For leaves these are the equivalent of the plate base (side leaf base is on)
            xv = numpy.repeat([x[:,0] - x[:,3]],4,axis=0).transpose()
            yv = numpy.repeat([y[:,0] - y[:,3]],4,axis=0).transpose()
            zv = numpy.repeat([z[:,0] - z[:,3]],4,axis=0).transpose()

            # Determine new leaf angles
            theta = numpy.repeat([self.getLeafAngles()],4,axis=0).transpose()
            dims = theta.shape
            if (distribution == "random"):
                newLeafAngle = numpy.repeat([numpy.random.uniform(low=0.0001, high=90.0-0.0001, size=dims[0])],4,axis=0).transpose()
            elif (distribution == "uniform"):
                if mla is not None:
                    newLeafAngle = numpy.repeat([[mla]*dims[0]],4,axis=0).transpose()
                else:
                    print "MLA is not set."
                    sys.exit()                    
            else:
                print "%s not yet implemented" % distribution
                sys.exit()
            
            # Adjust old to new zenith angles
            adjustment = newLeafAngle - theta            
            ztr = numpy.where(zt > 0, -zt, zt)
            xr,yr,zr = utilities.rotate3D(xv, yv, zv, xt, yt, ztr, adjustment)
            
            # Recalculate normals
            nx,ny,nz = utilities.calcFaceNormal(xr,yr,zr)
            
            # Send the results
            self.putLeafVertices(xr+x0,yr+y0,zr+z0,nx,ny,nz)


    def getFacetVertices(self,material="Leaf01"):
        """
        Returns n by m arrays for x, y and z vertices of facets.
        n is the number of facets and m is the number vertices per facet (3)
        """
        x = numpy.array(self.object["v"])[:,0]
        y = numpy.array(self.object["v"])[:,2]
        z = numpy.array(self.object["v"])[:,1]
        indexf = numpy.where(numpy.array(self.object["fid"]) == material)
        if indexf[0].size > 0:       
            fx = x[numpy.array(self.object["f"])[indexf]-1]
            fy = y[numpy.array(self.object["f"])[indexf]-1]
            fz = z[numpy.array(self.object["f"])[indexf]-1]
            return (fx,fy,fz)
        else:
            return None


    def getFacetNormals(self,material="Leaf01"):
        """
        Returns n by m arrays for x, y and z vertices of facets.
        n is the number of facets and m is the number vertices per facet (3)
        """
        x = numpy.array(self.object["vn"])[:,0]
        y = numpy.array(self.object["vn"])[:,2]
        z = numpy.array(self.object["vn"])[:,1]
        indexf = numpy.where(numpy.array(self.object["fid"]) == material)
        if indexf[0].size > 0:       
            nx = x[numpy.array(self.object["f"])[indexf]-1]
            ny = y[numpy.array(self.object["f"])[indexf]-1]
            nz = z[numpy.array(self.object["f"])[indexf]-1]
            return (nx,ny,nz)
        else:
            return None


    def getVertices(self,material=None):
        """
        Returns 1D arrays for x, y and z vertices for a specified material
        """
        if (material is None):
            x = numpy.array(self.object["v"])[:,0]
            y = numpy.array(self.object["v"])[:,2]
            z = numpy.array(self.object["v"])[:,1]
        else:    
            index = numpy.where(numpy.array(self.object["vid"]) == material)
            x = numpy.array(self.object["v"])[index][:,0]
            y = numpy.array(self.object["v"])[index][:,2]
            z = numpy.array(self.object["v"])[index][:,1]
        return (x,y,z)


    def getLeafVertices(self):
        """
        Returns n by m arrays for x, y and z vertices and facet normals of entire leaves.
        n is the number of leaves and m is the number vertices per leaf (4)
        Assumes each leaf is flat and has two triangles
        """
        index = numpy.where(numpy.logical_or(numpy.array(self.object["vid"]) == "Leaf1",numpy.array(self.object["vid"]) == "Leaf01"))
        count = index[0].size
        if (count > 0):
            x = numpy.array(self.object["v"])[index][:,0].reshape((count/4,4))
            y = numpy.array(self.object["v"])[index][:,2].reshape((count/4,4))
            z = numpy.array(self.object["v"])[index][:,1].reshape((count/4,4))
            nx = numpy.array(self.object["vn"])[index][:,0].reshape((count/4,4))
            ny = numpy.array(self.object["vn"])[index][:,2].reshape((count/4,4))
            nz = numpy.array(self.object["vn"])[index][:,1].reshape((count/4,4))
            return (x,y,z,nx,ny,nz)
        else:
            return None

   
    def putLeafVertices(self,x,y,z,nx,ny,nz):
        """
        Transforms n by m arrays for x, y and z vertices and vertex normals (n) of leaves
        resulting from getLeafVertices and updates self.object with the updated vertices
        """
        v = numpy.array([x.flatten(),z.flatten(),y.flatten()]).transpose()
        vn = numpy.array([[nx,nx,nx,nx],[nz,nz,nz,nz],[ny,ny,ny,ny]]).transpose().reshape(-1,3)
        nLeaf = len(v)
        newV = [v[i] for i in range(nLeaf)]
        newN = [vn[i] for i in range(nLeaf)]
        if (self.object["vid"].count("Leaf01") > 0):
            leafStart = self.object["vid"].index("Leaf01")
        else:
            leafStart = self.object["vid"].index("Leaf1")
        self.object["v"][leafStart:leafStart+nLeaf] = newV
        self.object["vn"][leafStart:leafStart+nLeaf] = newN

  
    def getFacetArea(self,material="Leaf01",axis=None):
        """
        Calculates total area and centroid height of facets for a specified material
        For projected 2D area, set axis to 1 (x), 2 (y) or 3 (z). Default is 3D area.
        """
        fxyz = self.getFacetVertices(material=material)
        if (fxyz is not None):    
            if (axis == 1):
                fxyx[0][:] = 0.0
            elif (axis == 2):
                fxyz[1][:] = 0.0
            elif (axis == 3):
                fxyz[2][:] = 0.0
            area = utilities.calcHeronArea(fxyz[0], fxyz[1], fxyz[2])
            zc = numpy.mean(fxyz[2],axis=1)
            return (zc, area)
        else:
            return (0.0, 0.0)
        
        
    def getFacetAreaBin(self,material="Leaf01",binsize=0.5,maxVal=50.0):
        """
        Calculates total area in height bins for a size and material
        """
        fxyz = self.getFacetVertices(material=material)
        bins = numpy.arange(start=0.0, stop=maxVal, step=binsize)
        area = numpy.zeros(len(bins))
        normal = numpy.array([0.0,0.0,1.0])

        for n,bin in enumerate(bins):

            # Get all facets overlapping bin
            index = numpy.where(numpy.logical_and(numpy.amax(fxyz[2], axis=1) >= bins[n], numpy.amin(fxyz[2], axis=1) <= (bin+binsize)))

            # Intersect each facet with bin
            for i in index[0]:

                # Get vertices of facets at bin edges
                fxBin = fxyz[0][i]
                fyBin = fxyz[1][i]
                fzBin = fxyz[2][i]
                for j in [[0,1],[0,2],[1,2]]:

                    p1 = numpy.array([fxBin[j[0]],fyBin[j[0]],fzBin[j[0]]])
                    p2 = numpy.array([fxBin[j[1]],fyBin[j[1]],fzBin[j[1]]])

                    # Intersect with lower bin edge
                    plint = utilities.planeInt(p1, p2, normal, numpy.array([0.0,0.0,bin]))
                    if numpy.logical_and(min(p1[2],p2[2]) < bin, max(p1[2],p2[2]) > bin):
                        fxBin = numpy.hstack((fxBin,plint[0]))
                        fyBin = numpy.hstack((fyBin,plint[1]))
                        fzBin = numpy.hstack((fzBin,plint[2]))

                    # Intersect with upper bin edge
                    plint = utilities.planeInt(p1, p2, normal, numpy.array([0.0,0.0,bin+binsize]))
                    if numpy.logical_and(min(p1[2],p2[2]) < (bin+binsize), max(p1[2],p2[2]) > (bin+binsize)):
                        fxBin = numpy.hstack((fxBin,plint[0]))
                        fyBin = numpy.hstack((fyBin,plint[1]))
                        fzBin = numpy.hstack((fzBin,plint[2]))                

                # Remove vertices outside bin and get area of resulting 3D polygon
                idx = numpy.where(numpy.logical_and(fzBin >= bin, fzBin <= (bin+binsize)))
                s = utilities.counterClockwiseSort(numpy.array([fxBin[idx],fyBin[idx],fzBin[idx]]).transpose())
                area[n] += utilities.calc3DPolyArea(fx=fxBin[idx][s], fy=fyBin[idx][s], fz=fzBin[idx][s]) 

            # Show progress
            sys.stdout.write("Extracting %s vertical profile (%i%%)\r" % (material, int(n / float(len(bins)) * 100.0)))

        return (bins, area)

        
    def getCrownAttributes(self):
        """
        Calculates the projected vertical area and maximum width of the crown
        """    
        x,y,z = self.getVertices()
        chull = utilities.convex_hull(x,y)
        area = utilities.calc3DPolyArea(fx=chull[:,0], fy=chull[:,1], fz=None)
        dm = spatial.distance.pdist(chull, 'euclidean')
        return area, numpy.amax(dm)

        
    def getHeightAttributes(self):
        """
        Calculates top height, and base crown height defined by lowest leaf and lowest bough
        """      
        indexLeaf = numpy.where(numpy.logical_or(numpy.array(self.object["vid"]) == "Leaf1",numpy.array(self.object["vid"]) == "Leaf01"))
        indexBough = numpy.where(numpy.array(self.object["vid"]) == "Bough")
        z = numpy.array(self.object["v"])[:,1]
        if indexLeaf[0].size > 0:
            hLeaf = numpy.amin(z[indexLeaf])
        else:
            hLeaf = -1
        if indexBough[0].size > 0:
            hBough = numpy.amin(z[indexBough])
        else:
            hBough = -1            
        return (numpy.amax(z), hLeaf, hBough)
    
    
    def getStemDiameter(self, height=1.3):    
        """
        Calculates stem diameter at a nominated height in m
        Works out where facet edges intersect a plane at the set height.
        As done in the field, we then take the perimeter of convex hull and assume a circle for diameter.
        """          
        fx,fy,fz = self.getFacetVertices(material="Trunk")
        index = numpy.where(numpy.logical_and(numpy.amin(fz, axis=1) <= height, numpy.amax(fz, axis=1) >= height))

        for i in index[0]:

            for j in [[0,1],[0,2],[1,2]]:
                p1 = numpy.array([fx[i][j[0]],fy[i][j[0]],fz[i][j[0]]])
                p2 = numpy.array([fx[i][j[1]],fy[i][j[1]],fz[i][j[1]]])
                plint = utilities.planeInt(p1, p2, numpy.array([0.0,0.0,1.0]), numpy.array([0.0,0.0,height]))

                if numpy.logical_and(min(p1[2],p2[2]) <= height, max(p1[2],p2[2]) >= height):
                    try:
                        tVertices
                    except NameError:
                        tVertices = plint
                    else:
                        tVertices = numpy.vstack((tVertices,plint))

        chull = utilities.convex_hull(tVertices[:,0],tVertices[:,1])
        perimeter = numpy.sum(numpy.sqrt((chull[:,0]-numpy.roll(chull[:,0],1))**2+(chull[:,1]-numpy.roll(chull[:,1],1))**2))
        return 2.0 * perimeter / (2 * numpy.pi)
            
