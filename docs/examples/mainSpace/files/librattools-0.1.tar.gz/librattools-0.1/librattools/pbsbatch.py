#!/bin/env python
"""
Contains the pbsBatch class
"""

import os
        
        
class pbsBatch:  
    """
    Running librat start jobs on the Queensland DERM HPC using PBS
    """
    
    def __init__(self):
        """
        Initialise job parameters
        """
        self.mem = 2
        self.walltime = "1:00:00"
        self.ncpu = 1
        self.group = "rscstd"
        self.path = './'
        self.option = 14
        self.object = None
        self.wavebands = None
        self.nOrder = 100
        self.matlib = None
        self.verbose = True

    
    def writeJob(self, fileName, cameraFile, lightFile):
        """
        Write PBS file    
        """
        obj = open(os.path.join('pbs',fileName), 'w')
        obj.write('#!/bin/bash\n')
        obj.write('source /etc/profile.d/modules.sh\n')
        obj.write('module load librat\n')
        obj.write('cd %s\n' % self.path)

        if self.verbose:
            obj.write('echo %i camera/%s camera/%s | start -v -m %i -RATsensor_wavebands %s %s\n' % \
                      (self.option, cameraFile, lightFile, self.nOrder, self.wavebands, self.object))
        else:
            obj.write('echo %i camera/%s camera/%s | start -m %i -RATsensor_wavebands %s %s\n' % \
                      (self.option, cameraFile, lightFile, self.nOrder, self.wavebands, self.object))

        obj.close()
        os.chmod(os.path.join('pbs',fileName), 0755)


    def submitJob(self, jobName, pbsFile):
        """
        Submit PBS job   
        """
        os.system('qsub -A %s -N %s -l walltime=%s -l mem=%sGb -l ncpus=%i -o %s/log pbs/%s' % \
                  (self.group, jobName, self.walltime, self.mem, self.ncpu, self.path, pbsFile))


    def checkPaths(self):
        """
        Check standard paths exists for simulation results    
        """
        logPath = os.path.join(self.path, "log")
        resultsPath = os.path.join(self.path, "results")
        cameraPath = os.path.join(self.path, "camera")
        pbsPath = os.path.join(self.path, "pbs")
        reflPath = os.path.join(self.path, "refl")
        objPath = os.path.join(self.path, "obj")
        if not os.path.exists(resultsPath):
            os.mkdir(resultsPath)
        if not os.path.exists(logPath):
            os.mkdir(logPath)        
        if not os.path.exists(cameraPath):
            os.mkdir(cameraPath)                 
        if not os.path.exists(pbsPath):
            os.mkdir(pbsPath)
        if not os.path.exists(reflPath):
            print "Directory refl does not exist."
            sys.exit()
        if not os.path.exists(self.matlib):
            print "Materials library does not exist."
            sys.exit()
        if not os.path.exists(objPath):
            print "Directory obj does not exist."
            sys.exit()

